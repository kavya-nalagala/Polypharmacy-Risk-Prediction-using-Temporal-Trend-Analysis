
import os
import pickle
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import torch

from phase5 import TemporalGCN
from phase6 import compute_temporal_risk, get_patient_risk

DATA_PATH = r"C:\Users\cknal\Downloads\deeplearning projectvs\deeplearning"



def load_everything():
    print("[INFO] Loading graph, model, vocab, and drug events...")

    
    with open(os.path.join(DATA_PATH, "temporal_graph.pkl"), "rb") as f:
        graph = pickle.load(f)

    
    with open(os.path.join(DATA_PATH, "drug_vocab.pkl"), "rb") as f:
        vocab = pickle.load(f)

    
    events_path = os.path.join(DATA_PATH, "patient_drug_events.pkl")
    if os.path.exists(events_path):
        with open(events_path, "rb") as f:
            drug_events = pickle.load(f)
    else:
        drug_events = {}
        print("[WARN] patient_drug_events.pkl NOT FOUND")

    
    X = graph["node_features"]
    num_patients = graph["num_patients"]

    model = TemporalGCN(
        in_channels=X.shape[1],
        hidden_channels=64,
        num_patients=num_patients
    )

    model_path = os.path.join(DATA_PATH, "temporal_gcn_model_tgcn.pt")
    model.load_state_dict(torch.load(model_path, map_location="cpu"))
    model.eval()

    return graph, model, vocab, drug_events



def pick_patient(drug_events):
    print("[INFO] Searching for patient with medication history...")

    for pid, ev in drug_events.items():
        if len(ev) > 0:
            print("[INFO] Selected patient:", pid)
            return pid

    raise RuntimeError("No patient has drug events!")



def get_top_drugs(patient_id, drug_events, top_k=10):
    from collections import Counter

    events = drug_events.get(patient_id, [])
    drug_list = []

    for rec in events:
        if len(rec) >= 2:  
            drug_list.append(rec[1])  

    if not drug_list:
        return {}

    counter = Counter(drug_list)
    return dict(counter.most_common(top_k))



def run_phase7():
    graph, model, vocab, drug_events = load_everything()

    
    patient_id = pick_patient(drug_events)

    
    risk = get_patient_risk(patient_id, graph, model)
    print(f"\n[INFO] Overall Predicted Risk for {patient_id}: {risk:.4f}")

    
    curve = compute_temporal_risk(patient_id, graph, model)

    plt.figure(figsize=(8, 4))
    plt.plot(curve, marker="o")
    plt.title(f"Temporal Risk Curve – Patient {patient_id}")
    plt.xlabel("Time Bin")
    plt.ylabel("Predicted Risk")
    plt.grid(True)

    curve_path = os.path.join(DATA_PATH, f"patient_{patient_id}_risk_curve.png")
    plt.tight_layout()
    plt.savefig(curve_path)
    plt.close()

    print("[INFO] Saved risk curve to:", curve_path)

    
    top_drugs = get_top_drugs(patient_id, drug_events)

    if top_drugs:
        plt.figure(figsize=(10, 4))
        plt.bar(top_drugs.keys(), top_drugs.values())
        plt.xticks(rotation=45, ha="right")
        plt.title(f"Top Drugs – Patient {patient_id}")
        plt.xlabel("Drug")
        plt.ylabel("Count")
        plt.tight_layout()

        drug_path = os.path.join(DATA_PATH, f"patient_{patient_id}_top_drugs.png")
        plt.savefig(drug_path)
        plt.close()

        print("[INFO] Saved top-drug chart to:", drug_path)
    else:
        print("[WARN] This patient has NO drug records.")

    print("\n[PHASE 7 COMPLETE]\n")



if __name__ == "__main__":
    run_phase7()
