
import numpy as np
import torch



def get_patient_risk(patient_id, graph, model):

    X = torch.tensor(graph["node_features"], dtype=torch.float32)

    edge_index_list = [
        torch.tensor(e, dtype=torch.long) for e in graph["edge_index_list"]
    ]

    logits = model(X, edge_index_list).detach().numpy()

    
    idx = graph["patient_id_to_node"][patient_id]

    risk = 1 / (1 + np.exp(-logits[idx]))

    return float(risk)



def compute_temporal_risk(patient_id, graph, model):

    X = torch.tensor(graph["node_features"], dtype=torch.float32)

    edge_list = graph["edge_index_list"]

    
    pid_index = graph["patient_id_to_node"][patient_id]

    temporal_risk = []

    
    h = model.input_proj(X)
    h = model.activation(h)

    for edge_np in edge_list:

        edge_index = torch.tensor(edge_np, dtype=torch.long)

        if edge_index.size(1) > 0:
            h = model.gcn(h, edge_index)
            h = model.activation(h)

        patient_embedding = h[pid_index]
        score = model.classifier(patient_embedding).item()

        risk = 1 / (1 + np.exp(-score))
        temporal_risk.append(risk)

    return temporal_risk
