

import pandas as pd
import numpy as np
import pickle
import os


try:
    from phase1 import PolypharmacyConfig
except ImportError:
    from phase1 import PolypharmacyConfig



def load_cohort_and_sequences(data_path):
    print("\nLoading ICU cohort...")
    cohort = pd.read_csv(os.path.join(data_path, "icu_cohort.csv"))
    print("Cohort shape:", cohort.shape)

    print("Loading drug vocabulary...")
    with open(os.path.join(data_path, "drug_vocab.pkl"), "rb") as f:
        drug_vocab = pickle.load(f)
    print("Number of drugs in vocab:", len(drug_vocab))

    print("Loading patient drug sequences...")
    with open(os.path.join(data_path, "patient_drug_sequences.pkl"), "rb") as f:
        patient_sequences = pickle.load(f)
    print("Number of patients with sequences:", len(patient_sequences))

    return cohort, drug_vocab, patient_sequences



def build_node_mappings(cohort, drug_vocab):
    print("\nBuilding node mappings...")

    
    patient_ids = cohort['subject_id'].tolist()
    num_patients = len(patient_ids)

    
    patient_id_to_node = {pid: i for i, pid in enumerate(patient_ids)}

    
    num_drugs = len(drug_vocab)

    
    base = num_patients
    drug_idx_to_node = {drug_idx: base + drug_idx for drug_idx in range(num_drugs)}

    print("Num patient nodes:", num_patients)
    print("Num drug nodes:", num_drugs)
    print("Total nodes:", num_patients + num_drugs)

    return patient_id_to_node, drug_idx_to_node, num_patients, num_drugs



def build_node_features_and_labels(cohort, patient_id_to_node, num_patients, num_drugs):
    print("\nBuilding node features and labels...")

    num_nodes = num_patients + num_drugs

    
    X = np.zeros((num_nodes, 2), dtype=float)

    
    y = np.zeros(num_patients, dtype=int)

    
    for _, row in cohort.iterrows():
        pid = row['subject_id']
        node_idx = patient_id_to_node[pid]

        age = row.get('age', 0.0)
        label = row.get('label', 0)

        
        X[node_idx, 0] = float(age) / 100.0
        X[node_idx, 1] = 1.0  
        y[node_idx] = int(label)

    print("Node feature matrix shape:", X.shape)
    print("Patient label vector shape:", y.shape)

    return X, y



def build_temporal_edges(patient_sequences, patient_id_to_node, drug_idx_to_node, num_drugs):
    print("\nBuilding temporal edges (patient–drug) ...")

    
    max_T = 0
    for seq in patient_sequences.values():
        if seq.shape[0] > max_T:
            max_T = seq.shape[0]

    print("Maximum number of time bins across patients:", max_T)

    
    edges_per_t = [[] for _ in range(max_T)]

    
    for pid, seq in patient_sequences.items():
        if pid not in patient_id_to_node:
            
            continue

        patient_node = patient_id_to_node[pid]
        T_p, D = seq.shape

        for t in range(T_p):
            active_drugs = np.where(seq[t] == 1)[0]  

            for d_idx in active_drugs:
                if d_idx >= num_drugs:
                    continue  

                drug_node = drug_idx_to_node[d_idx]

                
                edges_per_t[t].append((patient_node, drug_node))
                edges_per_t[t].append((drug_node, patient_node))

    
    edge_index_list = []
    for t in range(max_T):
        edges = edges_per_t[t]
        if len(edges) == 0:
            edge_index = np.empty((2, 0), dtype=int)
        else:
            edge_array = np.array(edges, dtype=int).T  
            edge_index = edge_array
        edge_index_list.append(edge_index)

    print("Constructed edge_index_list with length (time steps):", len(edge_index_list))
    return edge_index_list, max_T



def save_temporal_graph(data_path, edge_index_list, X, y,
                        patient_id_to_node, drug_idx_to_node,
                        num_patients, num_drugs, max_T):
    graph_obj = {
        "edge_index_list": edge_index_list,  
        "node_features": X,                  
        "patient_labels": y,                 
        "patient_id_to_node": patient_id_to_node,
        "drug_idx_to_node": drug_idx_to_node,
        "num_patients": num_patients,
        "num_drugs": num_drugs,
        "max_time_bins": max_T,
    }

    out_path = os.path.join(data_path, "temporal_graph.pkl")
    with open(out_path, "wb") as f:
        pickle.dump(graph_obj, f)

    print("\nSaved temporal graph object to:", out_path)



if __name__ == "__main__":

    print("\n==============================")
    print("   PHASE 4: GRAPH CONSTRUCTION")
    print("==============================\n")

    config = PolypharmacyConfig()
    data_path = r"C:\Users\cknal\Downloads\deeplearning projectvs\deeplearning"

    
    cohort, drug_vocab, patient_sequences = load_cohort_and_sequences(data_path)

    
    patient_id_to_node, drug_idx_to_node, num_patients, num_drugs = build_node_mappings(
        cohort, drug_vocab
    )

    
    X, y = build_node_features_and_labels(
        cohort, patient_id_to_node, num_patients, num_drugs
    )

    
    edge_index_list, max_T = build_temporal_edges(
        patient_sequences, patient_id_to_node, drug_idx_to_node, num_drugs
    )

    
    save_temporal_graph(
        data_path, edge_index_list, X, y,
        patient_id_to_node, drug_idx_to_node,
        num_patients, num_drugs, max_T
    )

    print("\n PHASE 4 COMPLETED SUCCESSFULLY!")
