import os
import pickle
import numpy as np
import torch

DATA_PATH=r"C:\Users\cknal\Downloads\deeplearning projectvs\deeplearning"
def compute_drug_risk_contribution(patient_id, graph, model, drug_events):

    
    vocab_path = os.path.join(DATA_PATH, "drug_vocab.pkl")

    drug_vocab = pickle.load(open(vocab_path, "rb"))

    X = torch.tensor(graph["node_features"], dtype=torch.float32)
    edge_list = graph["edge_index_list"]

    pid_index = graph["patient_id_to_node"][patient_id]

    baseline_logits = model(
        X, [torch.tensor(e, dtype=torch.long) for e in edge_list]
    )
    baseline_score = baseline_logits[pid_index].item()

    baseline_risk = 1/(1+np.exp(-baseline_score))

    contributions = {}

    patient_drugs = set([d[1] for d in drug_events.get(patient_id, [])])

    for drug_name in patient_drugs:

        if drug_name not in drug_vocab:
            continue

        drug_idx = drug_vocab[drug_name]
        drug_node = graph["drug_idx_to_node"][drug_idx]

        modified_edges = []
        for e in edge_list:
            e_copy = e.copy()
            keep = np.where((e_copy[0] != drug_node) & (e_copy[1] != drug_node))[0]
            modified_edges.append(e_copy[:, keep])

        new_logits = model(X, [torch.tensor(e, dtype=torch.long) for e in modified_edges])
        new_score = new_logits[pid_index].item()
        new_risk = 1/(1+np.exp(-new_score))

        contributions[drug_name] = baseline_risk - new_risk

    return dict(sorted(contributions.items(), key=lambda x: -abs(x[1])))