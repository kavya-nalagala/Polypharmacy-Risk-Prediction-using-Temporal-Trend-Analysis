import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os
import pickle
import torch

from phase5 import TemporalGCN
from phase6 import get_patient_risk, compute_temporal_risk
from phase7_drug_explain import compute_drug_risk_contribution



DATA_PATH = r"C:\Users\cknal\Downloads\deeplearning projectvs\deeplearning"


@st.cache_resource
def load_all_data():

    
    with open(os.path.join(DATA_PATH, "temporal_graph.pkl"), "rb") as f:
        graph = pickle.load(f)

    
    with open(os.path.join(DATA_PATH, "patient_drug_events.pkl"), "rb") as f:
        drug_events = pickle.load(f)

    
    with open(os.path.join(DATA_PATH, "drug_vocab.pkl"), "rb") as f:
        vocab = pickle.load(f)

    
    X = graph["node_features"]
    model = TemporalGCN(
        in_channels=X.shape[1],
        hidden_channels=64,
        num_patients=graph["num_patients"]
    )

    model.load_state_dict(
        torch.load(os.path.join(DATA_PATH, "temporal_gcn_model_tgcn.pt"), map_location="cpu")
    )
    model.eval()

    return graph, drug_events, vocab, model



def risk_level(score):
    if score < 0.30:
        return "🟢 LOW RISK"
    elif score < 0.60:
        return "🟡 MODERATE RISK"
    else:
        return "🔴 HIGH RISK"



def main():

    st.title("💊 Polypharmacy Risk Prediction Dashboard")
    st.write("A Temporal Graph Neural Network system for drug–interaction risk prediction.")

    
    graph, drug_events, vocab, model = load_all_data()

    
    st.subheader("🔍 Select a Patient")

    
    patient_ids = sorted(list(graph["patient_id_to_node"].keys()))

    selected_patient = st.selectbox("Choose a patient ID:", patient_ids)

    
    if st.button("Analyze Patient"):

        pid = selected_patient
        st.success(f"Analyzing Patient **{pid}** ...")

        
        st.subheader("🩸 Overall Polypharmacy Risk Score")
        risk_score = get_patient_risk(pid, graph, model)
        st.metric("Risk Score", f"{risk_score:.4f}")
        st.write(risk_level(risk_score))

        st.write("---")

        
        st.subheader("📈 Temporal Risk Curve")

        curve = compute_temporal_risk(pid, graph, model)

        fig, ax = plt.subplots(figsize=(8, 3))
        ax.plot(curve, marker="o")
        ax.set_title(f"Risk Over Time – Patient {pid}")
        ax.set_xlabel("Time Bin")
        ax.set_ylabel("Risk Score")
        ax.grid(True)
        st.pyplot(fig)

        st.write("---")

        
        st.subheader("💊 Drugs Administered to Patient")

        events = drug_events.get(pid, [])

        if len(events) == 0:
            st.warning("No drug records found for this patient.")
        else:
            df = pd.DataFrame(events, columns=["time_bin", "drug", "dose", "route"])
            st.dataframe(df)

        st.write("---")

        
        st.subheader("📊 Top Drugs by Frequency")

        if len(events) > 0:
            df_freq = pd.DataFrame(events, columns=["time_bin", "drug", "dose", "route"])
            counts = df_freq["drug"].value_counts().head(10)

            fig2, ax2 = plt.subplots(figsize=(8, 3))
            ax2.bar(counts.index, counts.values)
            ax2.set_title("Top 10 Drugs")
            ax2.set_ylabel("Count")
            plt.xticks(rotation=45, ha="right")
            st.pyplot(fig2)

        st.write("---")

        
        st.subheader("🔥 Drug Contribution to Risk")

        contrib = compute_drug_risk_contribution(pid, graph, model, drug_events)

        if len(contrib) == 0:
            st.warning("Not enough data to compute drug contributions.")
        else:
            contrib_df = pd.DataFrame(contrib.items(), columns=["Drug", "Risk_Change"])
            st.dataframe(contrib_df)

            
            fig3, ax3 = plt.subplots(figsize=(8, 3))
            ax3.bar(contrib_df["Drug"], contrib_df["Risk_Change"])
            ax3.set_title("Drug Risk Impact")
            ax3.set_ylabel("Δ Risk")
            plt.xticks(rotation=45, ha="right")
            st.pyplot(fig3)

            
            high_risk_drug = contrib_df.iloc[0]["Drug"]
            st.error(f"🚨 **Highest Impact Drug:** {high_risk_drug}")

        st.write("---")

        
        st.subheader("📝 Summary")

        st.write(f"**Patient ID:** {pid}")
        st.write(f"**Total Drugs Used:** {len(events)}")
        st.write(f"**Time Bins Monitored:** {len(curve)}")
        st.write(f"**Final Risk Level:** {risk_level(risk_score)}")



if __name__ == "__main__":
    main()
