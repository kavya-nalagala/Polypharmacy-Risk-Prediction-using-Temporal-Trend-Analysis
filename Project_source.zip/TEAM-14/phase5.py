

import os
import pickle
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import matplotlib.pyplot as plt

from torch_geometric.nn import GCNConv
from sklearn.metrics import roc_auc_score, mean_absolute_error, mean_squared_error



def load_temporal_graph(data_path):
    graph_path = os.path.join(data_path, "temporal_graph.pkl")
    with open(graph_path, "rb") as f:
        g = pickle.load(f)

    return (
        g["edge_index_list"],
        g["node_features"],
        g["patient_labels"],
        g["num_patients"],
        g["num_drugs"],
        g["max_time_bins"],
    )



class TemporalGCN(nn.Module):
    def __init__(self, in_channels, hidden_channels, num_patients):
        super().__init__()

        self.num_patients = num_patients

        self.input_proj = nn.Linear(in_channels, hidden_channels)
        self.gcn = GCNConv(hidden_channels, hidden_channels)
        self.activation = nn.ReLU()

        self.classifier = nn.Sequential(
            nn.Linear(hidden_channels, hidden_channels),
            nn.ReLU(),
            nn.Linear(hidden_channels, 1),
        )

    def forward(self, x, edge_index_list):
        h = self.activation(self.input_proj(x))

        for edge_index in edge_index_list:
            if edge_index.size(1) > 0:
                h = self.activation(self.gcn(h, edge_index))

        patient_embed = h[:self.num_patients]
        return self.classifier(patient_embed).squeeze(-1)



def create_splits(num_patients, train_ratio=0.7, val_ratio=0.15, seed=42):
    rng = np.random.default_rng(seed)
    idx = np.arange(num_patients)
    rng.shuffle(idx)

    n_train = int(train_ratio * num_patients)
    n_val = int(val_ratio * num_patients)

    return idx[:n_train], idx[n_train:n_train + n_val], idx[n_train + n_val:]



def compute_accuracy(logits, labels):
    preds = (torch.sigmoid(logits) >= 0.5).long()
    return (preds == labels.long()).float().mean().item()



def train_model(edge_index_list, X, y, num_patients,
                data_path, hidden_channels=64, lr=1e-3, num_epochs=20):

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    X = torch.tensor(X, dtype=torch.float32, device=device)
    y = torch.tensor(y, dtype=torch.float32, device=device)

    edge_index_tensors = [
        torch.tensor(e, dtype=torch.long, device=device)
        for e in edge_index_list
    ]

    model = TemporalGCN(
        in_channels=X.shape[1],
        hidden_channels=hidden_channels,
        num_patients=num_patients
    ).to(device)

    optimizer = optim.Adam(model.parameters(), lr=lr)
    criterion = nn.BCEWithLogitsLoss()

    train_idx, val_idx, test_idx = create_splits(num_patients)

    train_idx = torch.tensor(train_idx, device=device)
    val_idx = torch.tensor(val_idx, device=device)
    test_idx = torch.tensor(test_idx, device=device)

    train_losses = []
    val_losses = []
    train_accs = []
    val_accs = []

    for epoch in range(1, num_epochs + 1):
        model.train()
        optimizer.zero_grad()

        logits = model(X, edge_index_tensors)

        loss = criterion(logits[train_idx], y[train_idx])
        loss.backward()
        optimizer.step()

        train_loss = loss.item()
        train_acc = compute_accuracy(logits[train_idx], y[train_idx])

        
        model.eval()
        with torch.no_grad():
            val_logits = logits[val_idx]
            val_loss = criterion(val_logits, y[val_idx]).item()
            val_acc = compute_accuracy(val_logits, y[val_idx])

        train_losses.append(train_loss)
        val_losses.append(val_loss)
        train_accs.append(train_acc)
        val_accs.append(val_acc)

        print(
            f"Epoch {epoch:03d} | Train Loss {train_loss:.4f} | "
            f"Val Loss {val_loss:.4f} | Train Acc {train_acc:.4f} | Val Acc {val_acc:.4f}"
        )

    
    model.eval()
    with torch.no_grad():
        logits = model(X, edge_index_tensors)
        test_logits = logits[test_idx]
        test_labels = y[test_idx]

    test_probs = torch.sigmoid(test_logits).cpu().numpy()
    test_labels_np = test_labels.cpu().numpy()

    
    np.save(os.path.join(data_path, "test_logits_tgcn.npy"), test_probs)
    np.save(os.path.join(data_path, "test_labels_tgcn.npy"), test_labels_np)

    print("\n=== FINAL TEST RESULTS ===")
    print(f"Accuracy: {compute_accuracy(test_logits, test_labels):.4f}")
    print(f"AUC ROC: {roc_auc_score(test_labels_np, test_probs):.4f}")
    print(f"MAE: {mean_absolute_error(test_labels_np, test_probs):.4f}")
    print(f"MSE: {mean_squared_error(test_labels_np, test_probs):.4f}")

    
    plt.figure(figsize=(8, 4))
    plt.plot(train_losses, label="Train Loss")
    plt.plot(val_losses, label="Val Loss")
    plt.legend()
    plt.title("Loss Curve")
    plt.savefig(os.path.join(data_path, "loss_curve_tgcn.png"))
    plt.close()

    plt.figure(figsize=(8, 4))
    plt.plot(train_accs, label="Train Acc")
    plt.plot(val_accs, label="Val Acc")
    plt.legend()
    plt.title("Accuracy Curve")
    plt.savefig(os.path.join(data_path, "accuracy_curve_tgcn.png"))
    plt.close()

    return model



if __name__ == "__main__":

    data_path = r"C:\Users\cknal\Downloads\deeplearning projectvs\deeplearning"

    edge_list, X, y, num_patients, num_drugs, max_T = load_temporal_graph(data_path)

    model = train_model(
        edge_index_list=edge_list,
        X=X,
        y=y,
        num_patients=num_patients,
        data_path=data_path,
        hidden_channels=64,
        lr=1e-3,
        num_epochs=30
    )

    model_path = os.path.join(data_path, "temporal_gcn_model_tgcn.pt")
    torch.save(model.state_dict(), model_path)
    print("\nModel saved successfully.")
