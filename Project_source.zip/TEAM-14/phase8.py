

import os
import pickle
from pptx import Presentation
from pptx.util import Inches, Pt



DATA_PATH = r"C:\Users\cknal\Downloads\deeplearning projectvs\deeplearning"
PPTX_OUTPUT = os.path.join(DATA_PATH, "Polypharmacy_TGNN_Report.pptx")


PROJECT_TITLE = "Polypharmacy Risk Prediction using Temporal Trend Analysis"
AUTHOR_NAME = "N S Kavya"  
INSTITUTE = "Amrita School of Engineering, Bangalore"



def find_patient_plot_prefix(data_path):
    files = os.listdir(data_path)
    prefixes = []

    for f in files:
        if f.startswith("patient_") and f.endswith("_risk_curve.png"):
            
            core = f[len("patient_") : -len("_risk_curve.png")]
            prefixes.append(core)

    if not prefixes:
        return None

    
    return prefixes[0]



def load_basic_info(data_path):
    info = {}

    
    try:
        import pandas as pd
        cohort_path = os.path.join(data_path, "icu_cohort.csv")
        if os.path.exists(cohort_path):
            df = pd.read_csv(cohort_path)
            info["num_patients"] = df.shape[0]
        else:
            info["num_patients"] = "N/A"
    except Exception:
        info["num_patients"] = "N/A"

    
    try:
        with open(os.path.join(data_path, "drug_vocab.pkl"), "rb") as f:
            vocab = pickle.load(f)
        info["num_drugs"] = len(vocab)
    except Exception:
        info["num_drugs"] = "N/A"

    return info



def create_presentation(data_path, pptx_path):
    print("Creating PowerPoint report...")

    prs = Presentation()

    
    slide_layout = prs.slide_layouts[0]  
    slide = prs.slides.add_slide(slide_layout)

    title = slide.shapes.title
    subtitle = slide.placeholders[1]

    title.text = PROJECT_TITLE
    subtitle.text = f"{AUTHOR_NAME}\n{INSTITUTE}"

    
    slide_layout = prs.slide_layouts[1]  
    slide = prs.slides.add_slide(slide_layout)

    title = slide.shapes.title
    body = slide.placeholders[1]

    title.text = "Project Overview"

    tf = body.text_frame
    tf.text = (
        "Objective:\n"
        "  • Predict patient risk under polypharmacy using a Temporal Graph Neural Network (TGNN).\n"
        "  • Analyze how risk evolves over time with changing medication patterns.\n"
    )

    p = tf.add_paragraph()
    p.text = "Dataset:"
    p.level = 0

    p = tf.add_paragraph()
    p.text = "  • MIMIC-IV (v2.1) ICU patient cohort."
    p.level = 1

    p = tf.add_paragraph()
    p.text = "  • Prescriptions-based temporal medication sequences."
    p.level = 1

    p = tf.add_paragraph()
    p.text = "Model:"
    p.level = 0

    p = tf.add_paragraph()
    p.text = "  • Temporal GCN over patient–drug bipartite graphs."
    p.level = 1

    
    info = load_basic_info(data_path)
    slide = prs.slides.add_slide(slide_layout)
    title = slide.shapes.title
    body = slide.placeholders[1]

    title.text = "Cohort & Features"

    tf = body.text_frame
    tf.text = f"Number of ICU patients in cohort: {info.get('num_patients', 'N/A')}"
    p = tf.add_paragraph()
    p.text = f"Number of unique drugs considered: {info.get('num_drugs', 'N/A')}"
    p.level = 0

    p = tf.add_paragraph()
    p.text = "Node features:"
    p.level = 0

    p = tf.add_paragraph()
    p.text = "  • Patients: age (normalized), patient flag."
    p.level = 1

    p = tf.add_paragraph()
    p.text = "  • Drugs: structural node without intrinsic features."
    p.level = 1

    
    patient_prefix = find_patient_plot_prefix(data_path)
    if patient_prefix is None:
        print("No patient_*_risk_curve.png found. Please run Phase 7 first.")
        patient_prefix = "XXXX"

    risk_curve_path = os.path.join(data_path, f"patient_{patient_prefix}_risk_curve.png")
    top_drugs_path = os.path.join(data_path, f"patient_{patient_prefix}_top_drugs.png")
    heatmap_path = os.path.join(data_path, f"patient_{patient_prefix}_heatmap.png")

    
    if os.path.exists(risk_curve_path):
        slide = prs.slides.add_slide(slide_layout)
        title = slide.shapes.title
        title.text = f"Temporal Risk Curve – Patient {patient_prefix}"

        left = Inches(1)
        top = Inches(1.5)
        height = Inches(4.5)

        slide.shapes.add_picture(risk_curve_path, left, top, height=height)
    else:
        print("Warning: Risk curve image not found:", risk_curve_path)

    
    if os.path.exists(top_drugs_path):
        slide = prs.slides.add_slide(slide_layout)
        title = slide.shapes.title
        title.text = f"Top Drug Contributions – Patient {patient_prefix}"

        left = Inches(1)
        top = Inches(1.5)
        height = Inches(4.5)
        slide.shapes.add_picture(top_drugs_path, left, top, height=height)
    else:
        print("Warning: Top-drugs image not found:", top_drugs_path)

    
    if os.path.exists(heatmap_path):
        slide = prs.slides.add_slide(slide_layout)
        title = slide.shapes.title
        title.text = f"Drug–Time Importance Heatmap – Patient {patient_prefix}"

        left = Inches(0.5)
        top = Inches(1.3)
        height = Inches(4.8)
        slide.shapes.add_picture(heatmap_path, left, top, height=height)
    else:
        print("Warning: Heatmap image not found:", heatmap_path)

    
    slide = prs.slides.add_slide(slide_layout)
    title = slide.shapes.title
    body = slide.placeholders[1]

    title.text = "Conclusion & Future Work"
    tf = body.text_frame
    tf.text = "Conclusion:"

    p = tf.add_paragraph()
    p.text = "  • TGNN model captures temporal and relational effects of polypharmacy."
    p.level = 1

    p = tf.add_paragraph()
    p.text = "  • Enables patient-specific risk monitoring over ICU stay."
    p.level = 1

    p = tf.add_paragraph()
    p.text = "Future Work:"
    p.level = 0

    p = tf.add_paragraph()
    p.text = "  • Incorporate lab results and vital signs as additional node features."
    p.level = 1

    p = tf.add_paragraph()
    p.text = "  • Use attention-based models to better interpret drug interactions."
    p.level = 1

    p = tf.add_paragraph()
    p.text = "  • Evaluate model generalization on other hospital datasets."
    p.level = 1

    
    prs.save(pptx_path)
    print("PowerPoint saved to:", pptx_path)



if __name__ == "__main__":
    create_presentation(DATA_PATH, PPTX_OUTPUT)
