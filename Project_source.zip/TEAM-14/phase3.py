

import pandas as pd
import numpy as np
import pickle
from tqdm import tqdm

from phase1 import PolypharmacyConfig



def load_prescriptions(data_path):
    print("\nLoading PRESCRIPTIONS...")
    df = pd.read_csv(r'C:\Users\cknal\Downloads\deeplearning projectvs\deeplearning\hosp\prescriptions.csv')
    print("Prescriptions loaded:", df.shape)
    print("Columns:", list(df.columns))
    return df



def filter_prescriptions_for_cohort(prescriptions, cohort):

    print("\nFiltering prescriptions for ICU cohort...")

    merged = prescriptions.merge(
        cohort[['subject_id', 'hadm_id', 'intime']],
        on=['subject_id', 'hadm_id'],
        how='inner'
    )

    print("Filtered prescriptions:", merged.shape)
    return merged



def align_med_times(df):

    print("\nAligning medication timestamps to ICU intime...")

    
    df['starttime'] = pd.to_datetime(df['starttime'], errors='coerce')
    df['stoptime'] = pd.to_datetime(df['stoptime'], errors='coerce')

    
    df['hours_since_intime'] = (df['starttime'] - df['intime']).dt.total_seconds() / 3600.0

    
    df = df[df['hours_since_intime'] >= 0]

    print("Remaining rows after alignment:", df.shape)
    return df



def assign_time_bins(df, bin_hours):

    print(f"\nAssigning medications to {bin_hours}-hour time bins...")

    df['time_bin'] = (df['hours_since_intime'] // bin_hours).astype(int)

    print("Max time bin:", df['time_bin'].max())
    return df



def build_drug_vocabulary(df, max_drugs=300):

    print(f"\nBuilding drug vocabulary (top {max_drugs} drugs)...")

    df['drug'] = df['drug'].astype(str)
    top_drugs = df['drug'].value_counts().head(max_drugs).index.tolist()

    drug_to_idx = {drug: i for i, drug in enumerate(top_drugs)}

    print("Vocabulary size:", len(drug_to_idx))
    return drug_to_idx



def build_patient_sequences(df, cohort, drug_to_idx, bin_hours):

    print("\nBuilding patient temporal drug sequences...\n")

    patient_sequences = {}       
    patient_events = {}           
    vocab_size = len(drug_to_idx)

    for _, row in tqdm(cohort.iterrows(), total=cohort.shape[0]):
        pid = row['subject_id']

        patient_meds = df[df['subject_id'] == pid]

        if patient_meds.empty:
            continue

        max_bin = int(patient_meds['time_bin'].max())
        T = max_bin + 1

        
        seq = np.zeros((T, vocab_size), dtype=int)
        events = []   

        for _, rx in patient_meds.iterrows():
            drug = rx['drug']
            t = int(rx['time_bin'])

            
            if drug in drug_to_idx:
                seq[t][drug_to_idx[drug]] = 1

           
            events.append((
                t,
                drug,
                str(rx.get("dose_val_rx", "")),
                str(rx.get("route", ""))
            ))

        patient_sequences[pid] = seq
        patient_events[pid] = events

    print("Patients with sequences:", len(patient_sequences))
    return patient_sequences, patient_events



def save_pickle(obj, path):
    with open(path, "wb") as f:
        pickle.dump(obj, f)
    print("Saved:", path)



if __name__ == "__main__":

    print("\n==============================")
    print("     PHASE 3 STARTING")
    print("==============================\n")

    config = PolypharmacyConfig()
    data_path = r"C:\Users\cknal\Downloads\deeplearning projectvs\deeplearning"

    
    cohort = pd.read_csv(f"{data_path}/icu_cohort.csv") 
    cohort['intime'] = pd.to_datetime(cohort['intime'])

    
    prescriptions = load_prescriptions(data_path)

    
    filtered = filter_prescriptions_for_cohort(prescriptions, cohort)

    
    aligned = align_med_times(filtered)

    
    binned = assign_time_bins(aligned, config.time_bin_hours)

    
    drug_to_idx = build_drug_vocabulary(binned, config.max_drugs)

    
    sequences, events = build_patient_sequences(binned, cohort, drug_to_idx, config.time_bin_hours)

    
    save_pickle(drug_to_idx, f"{data_path}/drug_vocab.pkl")
    save_pickle(sequences, f"{data_path}/patient_drug_sequences.pkl")
    save_pickle(events, f"{data_path}/patient_drug_events.pkl")

    print("\n🎉 PHASE 3 COMPLETED SUCCESSFULLY!")
