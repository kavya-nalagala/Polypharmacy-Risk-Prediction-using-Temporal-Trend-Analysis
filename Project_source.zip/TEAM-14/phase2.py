

import pandas as pd
from datetime import datetime


from phase1 import PolypharmacyConfig, create_label



def calculate_age(admissions_df, patients_df):
    
    df = admissions_df.merge(
        patients_df[['subject_id', 'anchor_age']], 
        on='subject_id', 
        how='left'
    )
    df = df.rename(columns={'anchor_age': 'age'})
    return df


def load_mimic_files(data_path):

    print("\nLoading MIMIC-IV files...")

    patients = pd.read_csv(r'C:\Users\cknal\Downloads\deeplearning projectvs\deeplearning\core\patients.csv')
    admissions = pd.read_csv(r'C:\Users\cknal\Downloads\deeplearning projectvs\deeplearning\core\admissions.csv')
    icustays = pd.read_csv(r'C:\Users\cknal\Downloads\deeplearning projectvs\deeplearning\hosp\icustays.csv')

    print("Loaded:")
    print("patients:", patients.shape)
    print("admissions:", admissions.shape)
    print("icustays:", icustays.shape)

    return patients, admissions, icustays



def build_icu_cohort(config, patients, admissions, icustays):

    print("\nCreating labels using Phase 1 logic...")
    label_df = create_label(config, admissions, patients)

    print("Merging labels with admissions...")
    cohort = admissions.merge(
        label_df[['subject_id', 'hadm_id', 'label']],
        on=['subject_id', 'hadm_id'],
        how='left'
    )

    print("Adding age...")
    cohort = calculate_age(cohort, patients)

    print("Filtering by age >= ", config.min_age)
    cohort = cohort[cohort['age'] >= config.min_age]

    
    print("Merging with ICU stays...")

    icu_subset = icustays[['subject_id', 'hadm_id', 'stay_id', 'intime', 'outtime']].copy()
    icu_subset = icu_subset.rename(columns={'stay_id': 'icustay_id'})

    cohort = cohort.merge(
        icu_subset,
        on=['subject_id', 'hadm_id'],
        how='inner'
    )

    
    cohort['intime'] = pd.to_datetime(cohort['intime'])
    cohort['outtime'] = pd.to_datetime(cohort['outtime'])

    
    cohort['icu_hours'] = (cohort['outtime'] - cohort['intime']).dt.total_seconds() / 3600.0

    print("Filtering ICU stays > 24 hours...")
    cohort = cohort[cohort['icu_hours'] >= 24]

    
    print("Selecting first ICU stay per patient...")
    cohort = cohort.sort_values('intime')
    cohort = cohort.groupby('subject_id').head(1).reset_index(drop=True)

    print("\nFinal cohort shape:", cohort.shape)
    return cohort



if __name__ == "__main__":

    print("\n===============================")
    print(" PHASE 2: ICU COHORT CREATION ")
    print("===============================\n")

    
    config = PolypharmacyConfig()

    
    data_path = r"C:\Users\cknal\Downloads\deeplearning projectvs\deeplearning"

    
    patients, admissions, icustays = load_mimic_files(data_path)

    
    cohort = build_icu_cohort(
        config=config,
        patients=patients,
        admissions=admissions,
        icustays=icustays
    )

    
    output_path = f"{data_path}/icu_cohort.csv"
    cohort.to_csv(output_path, index=False)
    print(f"\nCohort saved successfully to: {output_path}")
    print("Phase 2 completed!")
