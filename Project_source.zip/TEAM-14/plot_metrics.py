import numpy as np
import matplotlib.pyplot as plt
import os

DATA_PATH = r"C:\Users\cknal\Downloads\deeplearning projectvs\deeplearning"


train_losses = np.load(os.path.join(DATA_PATH, "train_losses.npy"))
val_losses = np.load(os.path.join(DATA_PATH, "val_losses.npy"))
train_accs = np.load(os.path.join(DATA_PATH, "train_accs.npy"))
val_accs = np.load(os.path.join(DATA_PATH, "val_accs.npy"))


plt.figure(figsize=(8, 5))
plt.plot(train_losses, label="Train Loss")
plt.plot(val_losses, label="Validation Loss")
plt.title("Training vs Validation Loss")
plt.xlabel("Epoch")
plt.ylabel("Loss")
plt.legend()
plt.grid(True)
plt.savefig(os.path.join(DATA_PATH, "loss_plot_finetune.png"))
plt.show()


plt.figure(figsize=(8, 5))
plt.plot(train_accs, label="Train Accuracy")
plt.plot(val_accs, label="Validation Accuracy")
plt.title("Training vs Validation Accuracy")
plt.xlabel("Epoch")
plt.ylabel("Accuracy")
plt.legend()
plt.grid(True)
plt.savefig(os.path.join(DATA_PATH, "accuracy_plot_finetune.png"))
plt.show()

print("Plots saved:")
print(" - loss_plot_finetune.png")
print(" - accuracy_plot_finetune.png")