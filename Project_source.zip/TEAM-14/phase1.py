

import pandas as pd
from datetime import datetime

class PolypharmacyConfig:
    

    def __init__(self):

        
        self.prediction_task = "polypharmacy_risk_prediction"

        
        self.target_label = "icu_mortality"   

        
        self.task_description = (
            "Predict if a patient will experience an adverse outcome "
            "based on their temporal medication sequence."
        )

        
        self.time_bin_hours = 24

        
        self.max_drugs = 300

        
        self.min_age = 18
        self.dataset_name = "MIMIC-IV 2.1"




def create_mortality_label(admissions_df, patients_df):
    
    merged = admissions_df.merge(
        patients_df[['subject_id', 'dod']], 
        on='subject_id', 
        how='left'
    )

    def compute_label(row):
        
        if row['hospital_expire_flag'] == 1:
            return 1

        
        if pd.notnull(row['dod']) and pd.notnull(row['dischtime']):
            death_time = pd.to_datetime(row['dod'])
            discharge = pd.to_datetime(row['dischtime'])
            hours_gap = (death_time - discharge).total_seconds() / 3600.0

            if hours_gap <= 24:   
                return 1

        return 0

    merged['label'] = merged.apply(compute_label, axis=1)
    
    return merged[['subject_id', 'hadm_id', 'label']]


def create_label(config, admissions_df, patients_df):
    

    if config.target_label == "icu_mortality":
        return create_mortality_label(admissions_df, patients_df)

    elif config.target_label == "aki":
        
        raise NotImplementedError("AKI label creation not implemented yet")

    elif config.target_label == "side_effect":
        
        raise NotImplementedError("Side-effect label not implemented yet")

    else:
        raise ValueError("Unknown target label type")




if __name__ == "__main__":
    print("Running Phase 1: Problem Definition")

    
    patients = pd.read_csv(r'C:\Users\cknal\Downloads\deeplearning projectvs\deeplearning\core\patients.csv')
    admissions = pd.read_csv(r'C:\Users\cknal\Downloads\deeplearning projectvs\deeplearning\core\admissions.csv')

    
    config = PolypharmacyConfig()

    
    labels_df = create_label(
        config=config,
        admissions_df=admissions,
        patients_df=patients
    )

    print(labels_df.head())
    print("Phase 1 completed successfully!")
