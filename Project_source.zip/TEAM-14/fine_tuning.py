import os
import pickle
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch_geometric.nn import GCNConv



class TemporalGCN(nn.Module):
    def __init__(self, in_channels, hidden_channels, num_patients):
        super().__init__()
        self.num_patients = num_patients

        self.input_proj = nn.Linear(in_channels, hidden_channels)
        self.gcn = GCNConv(hidden_channels, hidden_channels)
        self.activation = nn.ReLU()

        self.classifier = nn.Sequential(
            nn.Linear(hidden_channels, hidden_channels),
            nn.ReLU(),
            nn.Linear(hidden_channels, 1),
        )

    def forward(self, x, edge_index_list):
        h = self.activation(self.input_proj(x))

        for edge_index in edge_index_list:
            if edge_index.size(1) > 0:
                h = self.activation(self.gcn(h, edge_index))

        patient_embed = h[:self.num_patients]
        return self.classifier(patient_embed).squeeze(-1)



def create_splits(num_patients, train_ratio=0.8, seed=42):
    rng = np.random.default_rng(seed)
    idx = np.arange(num_patients)
    rng.shuffle(idx)

    n_train = int(num_patients * train_ratio)

    return idx[:n_train], idx[n_train:]



def accuracy(pred, true):
    pred_class = (torch.sigmoid(pred) >= 0.5).long()
    return (pred_class == true.long()).float().mean().item()



def finetune_model(base_model_path, graph, data_path,
                   lr=1e-4, epochs=30, hidden_dim=64):

    print("\n[INFO] Starting Fine-Tuning...")

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    X = torch.tensor(graph["node_features"], dtype=torch.float32, device=device)
    y = torch.tensor(graph["patient_labels"], dtype=torch.float32, device=device)

    edge_index_list = [
        torch.tensor(e, dtype=torch.long, device=device)
        for e in graph["edge_index_list"]
    ]

    num_patients = graph["num_patients"]

    model = TemporalGCN(X.shape[1], hidden_dim, num_patients).to(device)

    print("[INFO] Loading base TGNN (safe mode)...")
    state_dict = torch.load(base_model_path, map_location=device, weights_only=True)
    model.load_state_dict(state_dict)

    train_idx, val_idx = create_splits(num_patients)
    train_idx = torch.tensor(train_idx, device=device)
    val_idx = torch.tensor(val_idx, device=device)

    optimizer = optim.Adam(model.parameters(), lr=lr)
    criterion = nn.BCEWithLogitsLoss()

    train_losses, val_losses, train_accs, val_accs = [], [], [], []


    for epoch in range(1, epochs + 1):
        model.train()
        optimizer.zero_grad()

        logits = model(X, edge_index_list)

        train_logits = logits[train_idx]
        train_labels = y[train_idx]

        loss = criterion(train_logits, train_labels)
        loss.backward()
        optimizer.step()

        model.eval()
        with torch.no_grad():
            val_logits = logits[val_idx]
            val_labels = y[val_idx]

            val_loss = criterion(val_logits, val_labels).item()
            train_acc = accuracy(train_logits, train_labels)
            val_acc = accuracy(val_logits, val_labels)

        train_losses.append(loss.item())
        val_losses.append(val_loss)
        train_accs.append(train_acc)
        val_accs.append(val_acc)

        print(
            f"Epoch {epoch:02d} | "
            f"Train Loss={loss.item():.4f} | Val Loss={val_loss:.4f} | "
            f"Train Acc={train_acc:.4f} | Val Acc={val_acc:.4f}"
        )


    torch.save(model.state_dict(), os.path.join(data_path, "temporal_gcn_model_finetuned.pt"))

    np.save(os.path.join(data_path, "train_losses.npy"), train_losses)
    np.save(os.path.join(data_path, "val_losses.npy"), val_losses)
    np.save(os.path.join(data_path, "train_accs.npy"), train_accs)
    np.save(os.path.join(data_path, "val_accs.npy"), val_accs)

    print("\n[INFO] Fine-tuning complete.")
    print("[INFO] Metrics saved as .npy files.")
    print("[INFO] Ready for plotting with plot_metrics.py")



if __name__ == "__main__":
    DATA_PATH = r"C:\Users\cknal\Downloads\deeplearning projectvs\deeplearning"

    with open(os.path.join(DATA_PATH, "temporal_graph.pkl"), "rb") as f:
        graph = pickle.load(f)

    base_model = os.path.join(DATA_PATH, "temporal_gcn_model_tgcn.pt")

    finetune_model(
        base_model_path=base_model,
        graph=graph,
        data_path=DATA_PATH,
        lr=1e-4,
        epochs=30,
        hidden_dim=64
    )